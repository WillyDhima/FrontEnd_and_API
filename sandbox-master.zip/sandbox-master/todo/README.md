# Todo App

Plain JavaScript todo app based on Watch and Code.