# Studio Ghibli App

- [View the tutorial](https://www.taniarascia.com/how-to-connect-to-an-api-with-javascript)

- [View the demo](https://taniarascia.github.io/sandbox/ghibli/)
