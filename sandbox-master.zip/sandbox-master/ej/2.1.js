// Triangle

var hash = '#';

for (i = 0; i < 7; i++) {
  console.log(hash);
  hash += '#';
}